package com.example.spaceapp.util

object Ids {
    fun newId(): Long = System.currentTimeMillis()
}
