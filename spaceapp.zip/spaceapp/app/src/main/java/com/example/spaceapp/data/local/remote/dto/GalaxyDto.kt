package com.example.spaceapp.data.remote.dto

data class GalaxyDto(
    val id: Long,
    val name: String,
    val type: String
)
